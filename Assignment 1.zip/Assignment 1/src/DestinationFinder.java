@FunctionalInterface
public interface DestinationFinder {
    Coordinate findDestination(Move current);
}
