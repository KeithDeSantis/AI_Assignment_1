@FunctionalInterface
public interface CostFinder {
    int findCost(int terrainCost, int totalCost);

}
