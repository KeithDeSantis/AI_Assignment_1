public class OutBoundsError extends Exception {

}
