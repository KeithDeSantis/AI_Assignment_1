public enum Action {
    Forward, Left, Right, Bash
}
