Group 30 Assignment 1:

Our source code in enclosed in this zip file. To run our code, the simplest
method is opening the project folder in your IDE, and configure the command
line arguments to be "filename of board" and "int choice of heuristic."
Our 10 example board are in the project directory. Should you want to test
a board using this method, make sure it is within the Assignment1 directory.

If you prefer to make the project then run it, navigate into the src directory
and use "javac Main.java" to make the .class files. Then, make sure your 
board.txt is in the same folder as the .class files and call
"java Main filename heuristic."
