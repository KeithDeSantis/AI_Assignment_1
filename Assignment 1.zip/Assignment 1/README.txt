Group 30 Assignment 1:


Our source code in enclosed in this zip file, in the A Star project folder. 

To run our code, navigate to the astar.jar file's directory, and input 

java -jar ./astar.jar <path to filename> <heuristic integer>

Ensure the filename is a valid path or is to a file in the same directory as astar.jar.


For example, our ten boards are in the same directory and can be run with heuristics 1-6.


If there are issue or you'd prefer to run the code in an IDE, open the A Star project folder in your IDE and run Main.java with the appropriate argument configurations ( <filename> <heuristic integer> ). In this case, ensure the board.txt file is in the project directory, but not necessarily in the src folder.

NOTE ** The IDE we used was Intellij, other IDE's may need additional setup.


If you have any issues running our code please reach out to us:
kwdesantis@wpi.edu
jhiggins@wpi.edu
ywang33@wpi.edu